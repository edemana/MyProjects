a = int(input("Enter the value of a: "))
b = int(input("Enter the value of b: "))

print(f"Sum: {a + b}\nDifference: {a - b}\nProduct: {a * b}\nQuotient: {a // b}\nRemainder: {a % b}\nExponent: {a**b}")

