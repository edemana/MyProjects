from time import asctime

print("Current time and date: ", asctime())