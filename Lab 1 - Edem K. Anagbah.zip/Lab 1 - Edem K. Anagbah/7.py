feet = int(input("Enter height (in feet): "))
inches = int(input("Enter height (in inches): "))

centimeters = feet * (12 * 2.54) + inches * 2.54

print("Height (in centimeters): ",centimeters)

