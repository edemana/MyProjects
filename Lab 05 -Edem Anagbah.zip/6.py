def return_unique_count():
    word = input("Enter word: ")
    my_dict = {}
    for char in word:
        if char not in my_dict:
            my_dict[char] = 1
    return len(my_dict)


print("Your word has", return_unique_count(), "unique characters.")
