def lower_upper_count(l):
    l = l.replace(" ", "")
    count = {"lower": 0, "upper": 0}
    for val in l:
        if val.isupper():
            count["upper"] += 1
        else:
            count["lower"] += 1
    return count


print(lower_upper_count("The boy is going to school"))
