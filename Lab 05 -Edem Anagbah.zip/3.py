def OddEvenCount(l):
    new_dict = {"odd": 0, "even": 0}
    for num in l:
        if num % 2 == 0:
            new_dict["even"] += 1
        else:
            new_dict["odd"] += 1

    return new_dict


print(OddEvenCount([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))
