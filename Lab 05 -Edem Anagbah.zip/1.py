user_input = input("Please enter a sentence: ")

user_input = user_input.replace(" ", "").lower()
new_dict = {}
for char in user_input:
    if char not in new_dict:
        new_dict[char] = 1
    else:
        new_dict[char] += 1

for key in sorted(new_dict):
    print(key, new_dict[key])
