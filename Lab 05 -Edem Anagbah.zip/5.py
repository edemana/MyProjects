def return_num():
    d = input("Enter decimal: ").replace(".", "")
    my_dict = {}
    for i in d:
        if i not in my_dict:
            my_dict[i] = 1
        else:
            my_dict[i] += 1
    return my_dict


print(return_num())
