import string


def is_anagram():
    translator = str.maketrans("", "", string.punctuation)
    first = (
        input("Enter sentence: ").replace(" ", "").strip().lower().translate(translator)
    )

    second = (
        input("Enter sentence: ").replace(" ", "").strip().lower().translate(translator)
    )
    if sorted(first) == sorted(second):
        return True
    else:
        return False


print(is_anagram())
