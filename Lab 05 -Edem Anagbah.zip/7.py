def is_anagram():
    first = input("Enter word: ").strip().replace(" ", "").lower()
    second = input("Enter word: ").strip().replace(" ", "").lower()
    if sorted(first) == sorted(second):
        return True
    else:
        return False


print(is_anagram())
