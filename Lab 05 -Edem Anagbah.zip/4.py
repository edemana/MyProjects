def count_values():
    value = "3.1415926535897932384626433832795028841971693993751".split(".")[1]
    new_dict = {}
    for dig in value:
        if dig not in new_dict:
            new_dict[dig] = 1
        else:
            new_dict[dig] += 1

    for dig in sorted(new_dict):
        print("The digit", dig, "has count", new_dict[dig])


count_values()
